

using Luban;

[assembly: RegisterBehaviour]
